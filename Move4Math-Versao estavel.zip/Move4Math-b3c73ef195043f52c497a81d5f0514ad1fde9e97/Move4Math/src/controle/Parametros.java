/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author Mayco, Matheus, Henrique
 */


//Não é usada essa classe.... manolo safado...
public class Parametros {
    private int NST;

    /**
     * @return the NST
     */
    public int getNST() {
        return NST;
    }

    /**
     * @param NST the NST to set
     */
    public void setNST(int NST) {
        this.NST = NST;
    }
        
}
