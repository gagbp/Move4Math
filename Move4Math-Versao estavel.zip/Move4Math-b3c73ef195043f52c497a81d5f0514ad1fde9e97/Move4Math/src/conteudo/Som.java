/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conteudo;

/**
 *
 * @author Mayco, Matheus, Henrique
 */
public class Som {
    private int id;
    private String descricao;
    private String som;
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the som
     */
    public String getSom() {
        return som;
    }

    /**
     * @param som the som to set
     */
    public void setSom(String som) {
        this.som = som;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
}
